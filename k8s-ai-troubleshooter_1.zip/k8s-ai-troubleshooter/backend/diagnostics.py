"""
Deterministic rule engine for common Kubernetes failure patterns.

Each rule inspects pods/events and, when it fires, produces an Issue with a
severity, a short title, the raw evidence it matched on, and a template
remediation. The AI analyzer (ai_analyzer.py) takes these Issues and turns
them into a richer natural-language root-cause explanation, but the app
works fully without any AI backend since these rules stand on their own.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Issue:
    id: str
    severity: str  # "critical" | "warning" | "info"
    category: str
    title: str
    namespace: str
    resource: str  # e.g. "Pod/checkout-api-xxx"
    summary: str
    evidence: list[str] = field(default_factory=list)
    suggested_fix: str = ""
    pod_name: str | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "severity": self.severity,
            "category": self.category,
            "title": self.title,
            "namespace": self.namespace,
            "resource": self.resource,
            "summary": self.summary,
            "evidence": self.evidence,
            "suggestedFix": self.suggested_fix,
            "podName": self.pod_name,
        }


def _parse_qty_to_mib(qty: str | None) -> float | None:
    """Very small resource-quantity parser for memory (Ki/Mi/Gi) — good enough for comparisons."""
    if not qty:
        return None
    qty = qty.strip()
    try:
        if qty.endswith("Gi"):
            return float(qty[:-2]) * 1024
        if qty.endswith("Mi"):
            return float(qty[:-2])
        if qty.endswith("Ki"):
            return float(qty[:-2]) / 1024
        if qty.endswith("m"):
            return None  # cpu, not memory
        return float(qty) / (1024 * 1024)
    except ValueError:
        return None


def analyze(pods: list[dict], events: list[dict], deployments: list[dict], nodes: list[dict]) -> list[Issue]:
    issues: list[Issue] = []
    events_by_pod: dict[str, list[dict]] = {}
    for e in events:
        obj = e.get("involvedObject", "")
        if obj.startswith("Pod/"):
            events_by_pod.setdefault(obj.split("/", 1)[1], []).append(e)

    for pod in pods:
        ns = pod["namespace"]
        name = pod["name"]
        pod_events = events_by_pod.get(name, [])
        for c in pod.get("containers", []):
            reason = (c.get("reason") or "").strip()
            state = c.get("state")
            restarts = c.get("restartCount", 0)

            if reason == "CrashLoopBackOff" or (state == "waiting" and "CrashLoop" in reason):
                issues.append(Issue(
                    id=f"{ns}/{name}/crashloop",
                    severity="critical",
                    category="CrashLoopBackOff",
                    title=f"{c['name']} is crash-looping",
                    namespace=ns,
                    resource=f"Pod/{name}",
                    pod_name=name,
                    summary=f"Container '{c['name']}' has restarted {restarts} times and is stuck in CrashLoopBackOff.",
                    evidence=[c.get("message") or "back-off restarting failed container"]
                    + [e["message"] for e in pod_events if e["reason"] in ("BackOff", "Unhealthy")][:3],
                    suggested_fix=(
                        "Check the container's exit reason and recent logs. Common causes: an unhandled "
                        "startup exception, a missing dependency/config, a failing readiness/liveness probe, "
                        "or the app crashing on a bad config value. Run `kubectl logs -p <pod> -c "
                        f"{c['name']} -n {ns}` to see the previous crash's output."
                    ),
                ))

            if reason == "OOMKilled" or "OOM" in reason.upper() or any(e["reason"] == "OOMKilling" for e in pod_events):
                limit_mem = _parse_qty_to_mib(pod.get("resources", {}).get("limits", {}).get("memory"))
                issues.append(Issue(
                    id=f"{ns}/{name}/oom",
                    severity="critical",
                    category="OOMKilled",
                    title=f"{c['name']} was OOMKilled",
                    namespace=ns,
                    resource=f"Pod/{name}",
                    pod_name=name,
                    summary=(
                        f"Container '{c['name']}' exceeded its memory limit"
                        + (f" ({limit_mem:.0f}Mi)" if limit_mem else "")
                        + " and was killed by the kernel."
                    ),
                    evidence=[c.get("message") or "exit code 137 (OOMKilled)"]
                    + [e["message"] for e in pod_events if e["reason"] == "OOMKilling"][:2],
                    suggested_fix=(
                        "Raise the container's memory limit if the workload legitimately needs more, or "
                        "investigate a possible memory leak / unbounded cache / large batch size. Compare "
                        "actual usage (`kubectl top pod`) against the configured limit before changing it."
                    ),
                ))

            if reason in ("ImagePullBackOff", "ErrImagePull"):
                issues.append(Issue(
                    id=f"{ns}/{name}/imagepull",
                    severity="critical",
                    category="ImagePullBackOff",
                    title=f"{c['name']} cannot pull its image",
                    namespace=ns,
                    resource=f"Pod/{name}",
                    pod_name=name,
                    summary=f"Image '{c.get('image')}' could not be pulled for container '{c['name']}'.",
                    evidence=[c.get("message") or "ImagePullBackOff"],
                    suggested_fix=(
                        "Verify the image name/tag exists in the registry (typo'd tags are the #1 cause), "
                        "check registry credentials / imagePullSecrets, and confirm the node can reach the "
                        "registry (network policy, private registry auth, or a rate limit)."
                    ),
                ))

            if state == "terminated" and reason == "Error" and "auth" in (c.get("message") or "").lower():
                issues.append(Issue(
                    id=f"{ns}/{name}/autherror",
                    severity="critical",
                    category="AuthenticationError",
                    title=f"{c['name']} failed with an authentication error",
                    namespace=ns,
                    resource=f"Pod/{name}",
                    pod_name=name,
                    summary=f"Container '{c['name']}' exited due to a credential/authentication failure.",
                    evidence=[c.get("message") or ""],
                    suggested_fix=(
                        "Check the referenced Secret exists in this namespace, is mounted/wired correctly, "
                        "and has not rotated out of date (e.g. a rotated DB password not reflected in the "
                        "app's Secret). Confirm the app is reading the credential from the expected env var."
                    ),
                ))

        # Pending / unschedulable pods
        if pod.get("phase") == "Pending":
            sched_events = [e for e in pod_events if e["reason"] == "FailedScheduling"]
            reason_text = sched_events[0]["message"] if sched_events else "Pod is not being scheduled onto any node."
            category = "Unschedulable"
            fix = (
                "Check node resource availability (`kubectl describe nodes`), taints/tolerations, node "
                "selectors/affinity rules, and whether the requested cpu/memory exceeds what any node can "
                "offer. If autoscaling is enabled, confirm the cluster autoscaler is actually adding nodes."
            )
            if "Insufficient cpu" in reason_text or "Insufficient memory" in reason_text:
                category = "InsufficientResources"
            issues.append(Issue(
                id=f"{pod['namespace']}/{pod['name']}/pending",
                severity="warning",
                category=category,
                title=f"Pod {pod['name']} is stuck Pending",
                namespace=pod["namespace"],
                resource=f"Pod/{pod['name']}",
                pod_name=pod["name"],
                summary=reason_text,
                evidence=[e["message"] for e in sched_events][:3] or [reason_text],
                suggested_fix=fix,
            ))

        # High restart count even without an obvious current failure state
        max_restarts = max((c.get("restartCount", 0) for c in pod.get("containers", [])), default=0)
        if max_restarts >= 5 and pod.get("phase") == "Running" and not any(
            i.pod_name == name and i.category in ("CrashLoopBackOff", "OOMKilled") for i in issues
        ):
            issues.append(Issue(
                id=f"{ns}/{name}/highrestarts",
                severity="warning",
                category="HighRestartCount",
                title=f"Pod {name} has restarted {max_restarts} times",
                namespace=ns,
                resource=f"Pod/{name}",
                pod_name=name,
                summary=f"Pod is currently Running but has restarted {max_restarts} times recently, which "
                        "usually indicates intermittent crashes or failing health checks.",
                evidence=[e["message"] for e in pod_events][:3],
                suggested_fix="Review previous container logs (`kubectl logs -p`) and probe configuration "
                              "for flakiness under load.",
            ))

    # Deployment rollout issues
    for d in deployments:
        if d["desired"] and d["ready"] < d["desired"]:
            issues.append(Issue(
                id=f"{d['namespace']}/{d['name']}/rollout",
                severity="warning" if d["ready"] > 0 else "critical",
                category="DegradedRollout",
                title=f"Deployment {d['name']} is degraded ({d['ready']}/{d['desired']} ready)",
                namespace=d["namespace"],
                resource=f"Deployment/{d['name']}",
                summary=f"Only {d['ready']} of {d['desired']} desired replicas are ready.",
                evidence=[f"ready={d['ready']} updated={d['updated']} available={d['available']} desired={d['desired']}"],
                suggested_fix="Inspect the pods owned by this Deployment for the underlying per-pod issue "
                              "(see related pod issues above) — the rollout won't complete until they pass "
                              "readiness checks.",
            ))

    # Node pressure
    for n in nodes:
        conditions = n.get("conditions", {})
        if conditions.get("MemoryPressure") == "True":
            issues.append(Issue(
                id=f"node/{n['name']}/mempressure",
                severity="warning",
                category="NodeMemoryPressure",
                title=f"Node {n['name']} is under memory pressure",
                namespace="-",
                resource=f"Node/{n['name']}",
                summary="Kubelet reports MemoryPressure=True; the node may start evicting pods.",
                evidence=[f"conditions={conditions}"],
                suggested_fix="Check what's consuming memory on this node (`kubectl top pod --all-namespaces "
                              "--sort-by=memory`), consider rebalancing workloads or scaling the node pool.",
            ))
        if conditions.get("DiskPressure") == "True":
            issues.append(Issue(
                id=f"node/{n['name']}/diskpressure",
                severity="warning",
                category="NodeDiskPressure",
                title=f"Node {n['name']} is under disk pressure",
                namespace="-",
                resource=f"Node/{n['name']}",
                summary="Kubelet reports DiskPressure=True; image pulls and pod scheduling may be affected.",
                evidence=[f"conditions={conditions}"],
                suggested_fix="Clean up unused images/volumes on the node, or increase disk size. Check for "
                              "runaway log files filling the node's disk.",
            ))
        if not n.get("ready", True):
            issues.append(Issue(
                id=f"node/{n['name']}/notready",
                severity="critical",
                category="NodeNotReady",
                title=f"Node {n['name']} is NotReady",
                namespace="-",
                resource=f"Node/{n['name']}",
                summary="Node's Ready condition is False — kubelet may be down or unreachable.",
                evidence=[f"conditions={conditions}"],
                suggested_fix="Check node health, kubelet logs, and whether the node needs to be drained and "
                              "replaced (`kubectl describe node`, `kubectl get events --field-selector "
                              f"involvedObject.name={n['name']}`).",
            ))

    severity_rank = {"critical": 0, "warning": 1, "info": 2}
    issues.sort(key=lambda i: severity_rank.get(i.severity, 3))
    return issues
