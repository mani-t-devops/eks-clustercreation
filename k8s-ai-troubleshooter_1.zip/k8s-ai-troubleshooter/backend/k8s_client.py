"""
Kubernetes data access layer.

Tries to talk to a real cluster via the local kubeconfig (or in-cluster
service account if running inside k8s). If no cluster is reachable, falls
back to a realistic mock dataset so the dashboard is fully demoable without
any cluster at all.
"""
from __future__ import annotations

import datetime
import logging
import random
from typing import Any

logger = logging.getLogger("k8s_client")

_LIVE = False
_v1 = None
_apps_v1 = None


def try_connect() -> bool:
    """Attempt to load kube config (local file or in-cluster). Returns True if live."""
    global _LIVE, _v1, _apps_v1
    try:
        from kubernetes import client, config

        try:
            config.load_kube_config()
        except Exception:
            config.load_incluster_config()

        _v1 = client.CoreV1Api()
        _apps_v1 = client.AppsV1Api()
        # Cheap call to confirm the cluster actually answers.
        _v1.list_namespace(limit=1, _request_timeout=3)
        _LIVE = True
        logger.info("Connected to live Kubernetes cluster.")
    except Exception as exc:  # noqa: BLE001
        _LIVE = False
        logger.warning("No live cluster reachable (%s). Using mock data.", exc)
    return _LIVE


def is_live() -> bool:
    return _LIVE


# ---------------------------------------------------------------------------
# Live cluster readers
# ---------------------------------------------------------------------------

def _pod_to_dict(pod) -> dict[str, Any]:
    cs_list = pod.status.container_statuses or []
    containers = []
    for cs in cs_list:
        state_name, reason, message = "running", None, None
        if cs.state.waiting:
            state_name, reason, message = "waiting", cs.state.waiting.reason, cs.state.waiting.message
        elif cs.state.terminated:
            state_name = "terminated"
            reason = cs.state.terminated.reason
            message = cs.state.terminated.message
            exit_code = cs.state.terminated.exit_code
        elif cs.state.running:
            state_name = "running"
        containers.append(
            {
                "name": cs.name,
                "ready": cs.ready,
                "restartCount": cs.restart_count,
                "state": state_name,
                "reason": reason,
                "message": message,
                "image": cs.image,
            }
        )
    resources = {}
    if pod.spec.containers:
        c0 = pod.spec.containers[0]
        if c0.resources:
            resources = {
                "requests": c0.resources.requests or {},
                "limits": c0.resources.limits or {},
            }
    return {
        "name": pod.metadata.name,
        "namespace": pod.metadata.namespace,
        "node": pod.spec.node_name,
        "phase": pod.status.phase,
        "startTime": str(pod.status.start_time) if pod.status.start_time else None,
        "containers": containers,
        "resources": resources,
        "labels": pod.metadata.labels or {},
        "ownerKind": (pod.metadata.owner_references[0].kind if pod.metadata.owner_references else None),
        "ownerName": (pod.metadata.owner_references[0].name if pod.metadata.owner_references else None),
    }


def get_pods(namespace: str | None = None) -> list[dict[str, Any]]:
    if not _LIVE:
        return _mock_pods(namespace)
    if namespace:
        pods = _v1.list_namespaced_pod(namespace).items
    else:
        pods = _v1.list_pod_for_all_namespaces().items
    return [_pod_to_dict(p) for p in pods]


def get_events(namespace: str | None = None, limit: int = 200) -> list[dict[str, Any]]:
    if not _LIVE:
        return _mock_events(namespace)
    if namespace:
        events = _v1.list_namespaced_event(namespace).items
    else:
        events = _v1.list_event_for_all_namespaces().items
    events = sorted(events, key=lambda e: e.last_timestamp or e.event_time or datetime.datetime.min.replace(tzinfo=datetime.timezone.utc), reverse=True)
    out = []
    for e in events[:limit]:
        out.append(
            {
                "namespace": e.metadata.namespace,
                "type": e.type,
                "reason": e.reason,
                "message": e.message,
                "count": e.count,
                "involvedObject": f"{e.involved_object.kind}/{e.involved_object.name}",
                "lastTimestamp": str(e.last_timestamp or e.event_time),
            }
        )
    return out


def get_deployments(namespace: str | None = None) -> list[dict[str, Any]]:
    if not _LIVE:
        return _mock_deployments(namespace)
    if namespace:
        deps = _apps_v1.list_namespaced_deployment(namespace).items
    else:
        deps = _apps_v1.list_deployment_for_all_namespaces().items
    out = []
    for d in deps:
        out.append(
            {
                "name": d.metadata.name,
                "namespace": d.metadata.namespace,
                "desired": d.spec.replicas,
                "ready": d.status.ready_replicas or 0,
                "updated": d.status.updated_replicas or 0,
                "available": d.status.available_replicas or 0,
            }
        )
    return out


def get_nodes() -> list[dict[str, Any]]:
    if not _LIVE:
        return _mock_nodes()
    nodes = _v1.list_node().items
    out = []
    for n in nodes:
        conditions = {c.type: c.status for c in (n.status.conditions or [])}
        out.append(
            {
                "name": n.metadata.name,
                "ready": conditions.get("Ready") == "True",
                "conditions": conditions,
                "capacity": n.status.capacity,
                "allocatable": n.status.allocatable,
            }
        )
    return out


def get_pod_logs(namespace: str, pod: str, container: str | None = None, tail_lines: int = 100) -> str:
    if not _LIVE:
        return _mock_logs(namespace, pod)
    try:
        return _v1.read_namespaced_pod_log(
            name=pod, namespace=namespace, container=container, tail_lines=tail_lines
        )
    except Exception as exc:  # noqa: BLE001
        return f"(could not fetch logs: {exc})"


def get_namespaces() -> list[str]:
    if not _LIVE:
        return sorted({p["namespace"] for p in _mock_pods(None)})
    return [ns.metadata.name for ns in _v1.list_namespace().items]


# ---------------------------------------------------------------------------
# Mock data (used whenever no live cluster is reachable)
# ---------------------------------------------------------------------------

_now = datetime.datetime.utcnow()


def _ts(minutes_ago: int) -> str:
    return (_now - datetime.timedelta(minutes=minutes_ago)).isoformat() + "Z"


_MOCK_PODS = [
    {
        "name": "checkout-api-7d9f8c6b5-x2j9k",
        "namespace": "payments",
        "node": "node-pool-a-1",
        "phase": "Running",
        "startTime": _ts(180),
        "containers": [
            {"name": "checkout-api", "ready": False, "restartCount": 14, "state": "waiting",
             "reason": "CrashLoopBackOff", "message": "back-off 5m0s restarting failed container",
             "image": "registry.internal/checkout-api:1.8.2"}
        ],
        "resources": {"requests": {"cpu": "250m", "memory": "256Mi"}, "limits": {"cpu": "500m", "memory": "512Mi"}},
        "labels": {"app": "checkout-api"}, "ownerKind": "ReplicaSet", "ownerName": "checkout-api-7d9f8c6b5",
    },
    {
        "name": "inventory-worker-6f4d8-a1b2c",
        "namespace": "payments",
        "node": "node-pool-a-2",
        "phase": "Running",
        "startTime": _ts(60),
        "containers": [
            {"name": "inventory-worker", "ready": False, "restartCount": 6, "state": "terminated",
             "reason": "OOMKilled", "message": "exit code 137",
             "image": "registry.internal/inventory-worker:2.3.0"}
        ],
        "resources": {"requests": {"cpu": "100m", "memory": "128Mi"}, "limits": {"cpu": "200m", "memory": "256Mi"}},
        "labels": {"app": "inventory-worker"}, "ownerKind": "ReplicaSet", "ownerName": "inventory-worker-6f4d8",
    },
    {
        "name": "web-frontend-5b7c9d-p9q8r",
        "namespace": "storefront",
        "node": None,
        "phase": "Pending",
        "startTime": None,
        "containers": [
            {"name": "web-frontend", "ready": False, "restartCount": 0, "state": "waiting",
             "reason": "ImagePullBackOff", "message": 'Back-off pulling image "registry.internal/web-frontend:v4.2.0-typo"',
             "image": "registry.internal/web-frontend:v4.2.0-typo"}
        ],
        "resources": {"requests": {"cpu": "200m", "memory": "256Mi"}, "limits": {}},
        "labels": {"app": "web-frontend"}, "ownerKind": "ReplicaSet", "ownerName": "web-frontend-5b7c9d",
    },
    {
        "name": "recommendation-svc-8c7d6-m3n4o",
        "namespace": "storefront",
        "node": None,
        "phase": "Pending",
        "startTime": None,
        "containers": [
            {"name": "recommendation-svc", "ready": False, "restartCount": 0, "state": "waiting",
             "reason": "Pending", "message": "0/3 nodes are available: 3 Insufficient cpu.",
             "image": "registry.internal/recommendation-svc:1.1.0"}
        ],
        "resources": {"requests": {"cpu": "2", "memory": "1Gi"}, "limits": {"cpu": "2", "memory": "1Gi"}},
        "labels": {"app": "recommendation-svc"}, "ownerKind": "ReplicaSet", "ownerName": "recommendation-svc-8c7d6",
    },
    {
        "name": "auth-service-9a8b7-q1w2e",
        "namespace": "platform",
        "node": "node-pool-a-1",
        "phase": "Running",
        "startTime": _ts(600),
        "containers": [
            {"name": "auth-service", "ready": True, "restartCount": 0, "state": "running",
             "reason": None, "message": None, "image": "registry.internal/auth-service:3.0.1"}
        ],
        "resources": {"requests": {"cpu": "100m", "memory": "128Mi"}, "limits": {"cpu": "250m", "memory": "256Mi"}},
        "labels": {"app": "auth-service"}, "ownerKind": "ReplicaSet", "ownerName": "auth-service-9a8b7",
    },
    {
        "name": "db-migrator-job-4k5l6",
        "namespace": "platform",
        "node": "node-pool-a-2",
        "phase": "Failed",
        "startTime": _ts(45),
        "containers": [
            {"name": "db-migrator", "ready": False, "restartCount": 3, "state": "terminated",
             "reason": "Error", "message": "exit code 1: FATAL: password authentication failed for user \"migrator\"",
             "image": "registry.internal/db-migrator:0.9.4"}
        ],
        "resources": {"requests": {"cpu": "100m", "memory": "128Mi"}, "limits": {}},
        "labels": {"app": "db-migrator"}, "ownerKind": "Job", "ownerName": "db-migrator-job",
    },
    {
        "name": "search-indexer-3c2b1-z9y8x",
        "namespace": "platform",
        "node": "node-pool-a-3",
        "phase": "Running",
        "startTime": _ts(1200),
        "containers": [
            {"name": "search-indexer", "ready": True, "restartCount": 1, "state": "running",
             "reason": None, "message": None, "image": "registry.internal/search-indexer:2.0.0"}
        ],
        "resources": {"requests": {"cpu": "500m", "memory": "512Mi"}, "limits": {"cpu": "1", "memory": "1Gi"}},
        "labels": {"app": "search-indexer"}, "ownerKind": "StatefulSet", "ownerName": "search-indexer",
    },
]

_MOCK_EVENTS = [
    {"namespace": "payments", "type": "Warning", "reason": "BackOff", "count": 47,
     "message": "Back-off restarting failed container checkout-api in pod checkout-api-7d9f8c6b5-x2j9k",
     "involvedObject": "Pod/checkout-api-7d9f8c6b5-x2j9k", "lastTimestamp": _ts(2)},
    {"namespace": "payments", "type": "Warning", "reason": "Unhealthy", "count": 12,
     "message": "Readiness probe failed: HTTP probe failed with statuscode: 500",
     "involvedObject": "Pod/checkout-api-7d9f8c6b5-x2j9k", "lastTimestamp": _ts(3)},
    {"namespace": "payments", "type": "Warning", "reason": "OOMKilling", "count": 6,
     "message": "Memory cgroup out of memory: Killed process (inventory-worker) total-vm:912340kB, anon-rss:262144kB",
     "involvedObject": "Pod/inventory-worker-6f4d8-a1b2c", "lastTimestamp": _ts(9)},
    {"namespace": "storefront", "type": "Warning", "reason": "Failed", "count": 8,
     "message": 'Failed to pull image "registry.internal/web-frontend:v4.2.0-typo": rpc error: manifest unknown',
     "involvedObject": "Pod/web-frontend-5b7c9d-p9q8r", "lastTimestamp": _ts(4)},
    {"namespace": "storefront", "type": "Warning", "reason": "FailedScheduling", "count": 23,
     "message": "0/3 nodes are available: 3 Insufficient cpu.",
     "involvedObject": "Pod/recommendation-svc-8c7d6-m3n4o", "lastTimestamp": _ts(1)},
    {"namespace": "platform", "type": "Warning", "reason": "BackOff", "count": 3,
     "message": "Back-off restarting failed container db-migrator in pod db-migrator-job-4k5l6",
     "involvedObject": "Pod/db-migrator-job-4k5l6", "lastTimestamp": _ts(20)},
]

_MOCK_DEPLOYMENTS = [
    {"name": "checkout-api", "namespace": "payments", "desired": 3, "ready": 1, "updated": 3, "available": 1},
    {"name": "inventory-worker", "namespace": "payments", "desired": 2, "ready": 1, "updated": 2, "available": 1},
    {"name": "web-frontend", "namespace": "storefront", "desired": 4, "ready": 0, "updated": 4, "available": 0},
    {"name": "recommendation-svc", "namespace": "storefront", "desired": 2, "ready": 0, "updated": 2, "available": 0},
    {"name": "auth-service", "namespace": "platform", "desired": 2, "ready": 2, "updated": 2, "available": 2},
]

_MOCK_NODES = [
    {"name": "node-pool-a-1", "ready": True, "conditions": {"Ready": "True", "MemoryPressure": "False", "DiskPressure": "False"},
     "capacity": {"cpu": "4", "memory": "16Gi"}, "allocatable": {"cpu": "3800m", "memory": "14.5Gi"}},
    {"name": "node-pool-a-2", "ready": True, "conditions": {"Ready": "True", "MemoryPressure": "True", "DiskPressure": "False"},
     "capacity": {"cpu": "4", "memory": "16Gi"}, "allocatable": {"cpu": "3800m", "memory": "14.5Gi"}},
    {"name": "node-pool-a-3", "ready": True, "conditions": {"Ready": "True", "MemoryPressure": "False", "DiskPressure": "False"},
     "capacity": {"cpu": "8", "memory": "32Gi"}, "allocatable": {"cpu": "7800m", "memory": "30Gi"}},
]

_MOCK_LOGS = {
    "checkout-api-7d9f8c6b5-x2j9k": (
        "2026-09-04T05:12:01Z INFO  starting checkout-api v1.8.2\n"
        "2026-09-04T05:12:01Z INFO  connecting to postgres://payments-db:5432/checkout\n"
        "2026-09-04T05:12:02Z ERROR failed to connect to redis at redis-cache:6379: dial tcp: connect: connection refused\n"
        "2026-09-04T05:12:02Z FATAL panic: cannot start server without cache connection\n"
        "2026-09-04T05:12:02Z INFO  shutting down\n"
    ),
    "inventory-worker-6f4d8-a1b2c": (
        "2026-09-04T05:40:11Z INFO  processing batch of 5000 sku updates\n"
        "2026-09-04T05:40:44Z WARN  heap usage at 240Mi / 256Mi limit\n"
        "2026-09-04T05:40:51Z WARN  heap usage at 255Mi / 256Mi limit\n"
        "2026-09-04T05:40:52Z ERROR container killed: out of memory\n"
    ),
}


def _mock_pods(namespace: str | None) -> list[dict[str, Any]]:
    if namespace:
        return [p for p in _MOCK_PODS if p["namespace"] == namespace]
    return _MOCK_PODS


def _mock_events(namespace: str | None) -> list[dict[str, Any]]:
    if namespace:
        return [e for e in _MOCK_EVENTS if e["namespace"] == namespace]
    return _MOCK_EVENTS


def _mock_deployments(namespace: str | None) -> list[dict[str, Any]]:
    if namespace:
        return [d for d in _MOCK_DEPLOYMENTS if d["namespace"] == namespace]
    return _MOCK_DEPLOYMENTS


def _mock_nodes() -> list[dict[str, Any]]:
    return _MOCK_NODES


def _mock_logs(namespace: str, pod: str) -> str:
    return _MOCK_LOGS.get(pod, f"(no recent logs available for {pod} in mock mode)\n")
