from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import ai_analyzer
import diagnostics
import k8s_client

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("app")

app = FastAPI(title="AI-Powered Kubernetes Troubleshooter")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

FRONTEND_DIR = Path(__file__).parent.parent / "frontend"


@app.on_event("startup")
def startup() -> None:
    k8s_client.try_connect()


# ---------------------------------------------------------------------------
# API models
# ---------------------------------------------------------------------------

class ChatRequest(BaseModel):
    question: str
    namespace: Optional[str] = None


class DiagnoseRequest(BaseModel):
    issue_id: str
    namespace: Optional[str] = None


# ---------------------------------------------------------------------------
# API routes
# ---------------------------------------------------------------------------

@app.get("/api/status")
def status():
    return {
        "live": k8s_client.is_live(),
        "aiAvailable": ai_analyzer.ai_available(),
        "mode": "live-cluster" if k8s_client.is_live() else "demo-data",
    }


@app.post("/api/reconnect")
def reconnect():
    live = k8s_client.try_connect()
    return {"live": live}


@app.get("/api/namespaces")
def namespaces():
    return {"namespaces": k8s_client.get_namespaces()}


def _collect(namespace: Optional[str]):
    pods = k8s_client.get_pods(namespace)
    events = k8s_client.get_events(namespace)
    deployments = k8s_client.get_deployments(namespace)
    nodes = k8s_client.get_nodes()
    issues = diagnostics.analyze(pods, events, deployments, nodes)
    return pods, events, deployments, nodes, issues


@app.get("/api/overview")
def overview(namespace: Optional[str] = Query(None)):
    pods, events, deployments, nodes, issues = _collect(namespace)
    counts = {"critical": 0, "warning": 0, "info": 0}
    for i in issues:
        counts[i.severity] = counts.get(i.severity, 0) + 1
    return {
        "podCount": len(pods),
        "runningPods": sum(1 for p in pods if p["phase"] == "Running"),
        "pendingPods": sum(1 for p in pods if p["phase"] == "Pending"),
        "failedPods": sum(1 for p in pods if p["phase"] == "Failed"),
        "deploymentCount": len(deployments),
        "nodeCount": len(nodes),
        "nodesNotReady": sum(1 for n in nodes if not n.get("ready", True)),
        "issueCounts": counts,
        "totalIssues": len(issues),
    }


@app.get("/api/issues")
def issues(namespace: Optional[str] = Query(None)):
    _, _, _, _, issues_ = _collect(namespace)
    return {"issues": [i.to_dict() for i in issues_]}


@app.get("/api/pods")
def pods(namespace: Optional[str] = Query(None)):
    return {"pods": k8s_client.get_pods(namespace)}


@app.get("/api/deployments")
def deployments(namespace: Optional[str] = Query(None)):
    return {"deployments": k8s_client.get_deployments(namespace)}


@app.get("/api/nodes")
def nodes():
    return {"nodes": k8s_client.get_nodes()}


@app.get("/api/events")
def events(namespace: Optional[str] = Query(None)):
    return {"events": k8s_client.get_events(namespace)}


@app.get("/api/logs")
def logs(namespace: str, pod: str, container: Optional[str] = None):
    return {"logs": k8s_client.get_pod_logs(namespace, pod, container)}


@app.post("/api/diagnose")
def diagnose(req: DiagnoseRequest):
    _, events, _, _, issues_ = _collect(req.namespace)
    match = next((i for i in issues_ if i.id == req.issue_id), None)
    if not match:
        raise HTTPException(404, f"Issue {req.issue_id} not found (it may have resolved).")

    logs_text = None
    if match.pod_name:
        logs_text = k8s_client.get_pod_logs(match.namespace, match.pod_name)

    result = ai_analyzer.explain_issue(match.to_dict(), logs=logs_text)
    return {"issue": match.to_dict(), "diagnosis": result}


@app.post("/api/chat")
def chat(req: ChatRequest):
    pods, events, deployments, nodes, issues_ = _collect(req.namespace)
    context = {
        "namespaceFilter": req.namespace,
        "pods": [
            {
                "name": p["name"], "namespace": p["namespace"], "phase": p["phase"],
                "containers": [
                    {"name": c["name"], "state": c["state"], "reason": c.get("reason"),
                     "restarts": c.get("restartCount")}
                    for c in p.get("containers", [])
                ],
            }
            for p in pods
        ],
        "deployments": deployments,
        "nodes": [{"name": n["name"], "ready": n.get("ready"), "conditions": n.get("conditions")} for n in nodes],
        "detectedIssues": [i.to_dict() for i in issues_],
        "recentEvents": events[:30],
    }
    answer = ai_analyzer.chat(req.question, json.dumps(context, default=str, indent=2))
    return {"answer": answer}


# Serve the frontend last so /api/* routes above take precedence.
if FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("app:app", host="0.0.0.0", port=int(os.environ.get("PORT", 8000)), reload=False)
