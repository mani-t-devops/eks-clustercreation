"""
AI enrichment layer. If ANTHROPIC_API_KEY is set, sends the rule-engine's
Issue plus supporting evidence (logs, events) to Claude for a plain-English
root-cause explanation, a confidence-rated diagnosis, and step-by-step
remediation. Without a key, falls back to a clear templated explanation
built entirely from the rule engine's own output, so the app is fully
useful with zero external dependencies.
"""
from __future__ import annotations

import os
from typing import Any

_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-5")


def _client():
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return None
    try:
        import anthropic

        return anthropic.Anthropic(api_key=api_key)
    except Exception:
        return None


def ai_available() -> bool:
    return _client() is not None


def _fallback_explanation(issue: dict, logs: str | None) -> dict[str, Any]:
    lines = [
        f"**{issue['title']}**",
        "",
        issue["summary"],
    ]
    if issue.get("evidence"):
        lines.append("")
        lines.append("Evidence:")
        for ev in issue["evidence"]:
            lines.append(f"- {ev}")
    if logs:
        snippet = "\n".join(logs.strip().splitlines()[-6:])
        lines.append("")
        lines.append("Recent log tail:")
        lines.append(f"```\n{snippet}\n```")
    lines.append("")
    lines.append("Suggested fix:")
    lines.append(issue.get("suggestedFix", "No automated suggestion available."))
    return {
        "source": "rules",
        "explanation": "\n".join(lines),
        "confidence": "medium",
    }


def explain_issue(issue: dict, logs: str | None = None, extra_context: str | None = None) -> dict[str, Any]:
    client = _client()
    if client is None:
        return _fallback_explanation(issue, logs)

    evidence_block = "\n".join("  - " + e for e in issue.get("evidence", []))
    logs_block = ("Recent container logs:\n" + logs[-4000:]) if logs else "No logs available."
    prompt = f"""You are an expert Kubernetes SRE. A rule-based diagnostic engine has already
detected the following issue in a live cluster. Your job is to give the on-call engineer a
crisp, accurate root-cause analysis and concrete remediation steps.

Issue detected:
- Category: {issue['category']}
- Resource: {issue['resource']} (namespace: {issue['namespace']})
- Title: {issue['title']}
- Summary: {issue['summary']}
- Evidence:
{evidence_block}
- Rule engine's generic suggested fix: {issue.get('suggestedFix', 'none')}

{logs_block}

{extra_context or ''}

Respond in markdown with these sections:
### Root cause
A specific, confident explanation of what's actually happening (not generic boilerplate) —
reason from the evidence and logs given, and call out anything that looks like the most likely
single root cause versus other possibilities.
### Remediation steps
A numbered, concrete list of steps to fix it, most-likely-fix first, including any exact
kubectl commands that would help confirm or resolve it.
### Risk if ignored
One or two sentences on what happens if this isn't addressed.

Keep it tight — no preamble, no restating the question, no closing pleasantries."""

    try:
        resp = client.messages.create(
            model=_MODEL,
            max_tokens=900,
            messages=[{"role": "user", "content": prompt}],
        )
        text = "".join(block.text for block in resp.content if hasattr(block, "text"))
        return {"source": "claude", "explanation": text, "confidence": "high"}
    except Exception as exc:  # noqa: BLE001
        fb = _fallback_explanation(issue, logs)
        fb["explanation"] += f"\n\n_(AI enrichment unavailable: {exc})_"
        return fb


def chat(question: str, cluster_context: str) -> str:
    client = _client()
    if client is None:
        return (
            "AI chat requires an ANTHROPIC_API_KEY to be set on the server. In the meantime, "
            "use the Issues panel — every detected problem includes a rule-based summary and "
            "suggested fix.\n\nCluster context that would have been sent to the model:\n\n"
            f"```\n{cluster_context[:2000]}\n```"
        )
    prompt = f"""You are an AI Kubernetes troubleshooting assistant embedded in a live dashboard.
Here is the current state of the cluster (pods, issues, events) the dashboard has collected:

{cluster_context[:6000]}

The on-call engineer asks: "{question}"

Answer directly and concretely using the cluster state above. If the answer isn't determinable
from the given context, say so plainly and suggest what to check next. Keep the answer focused,
use markdown, and prefer bullet points / kubectl commands over prose where useful."""
    try:
        resp = client.messages.create(
            model=_MODEL,
            max_tokens=800,
            messages=[{"role": "user", "content": prompt}],
        )
        return "".join(block.text for block in resp.content if hasattr(block, "text"))
    except Exception as exc:  # noqa: BLE001
        return f"AI request failed: {exc}"
