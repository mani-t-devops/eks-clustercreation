# AI-Powered Kubernetes Troubleshooter

A web dashboard that watches your Kubernetes cluster, runs a rule engine over
pods/events/nodes/deployments to detect common failure patterns, and uses
Claude to turn each detected issue into a plain-English root-cause analysis
with concrete remediation steps. Includes a chat box to ask free-form
questions about the current cluster state.

Runs in two modes automatically:
- **Live cluster** — if it can load your kubeconfig (or an in-cluster service
  account) and reach the API server, it reads real data.
- **Demo data** — if no cluster is reachable, it falls back to a realistic
  mock dataset (a crash-looping pod, an OOMKilled worker, an ImagePullBackOff,
  a Pending pod stuck on insufficient CPU, a degraded rollout, a node under
  memory pressure, etc.) so you can try the whole app with zero setup.

## What it detects

- CrashLoopBackOff
- OOMKilled
- ImagePullBackOff / ErrImagePull
- Authentication/credential errors in container exit messages
- Pending / unschedulable pods (including "Insufficient cpu/memory")
- Pods with unusually high restart counts
- Degraded Deployment rollouts (ready < desired)
- Node MemoryPressure / DiskPressure / NotReady

Every finding gets a severity (critical/warning/info), the raw evidence it
matched on, and a template fix — all of which work with **zero external AI
dependency**. When `ANTHROPIC_API_KEY` is set, each issue is additionally
sent to Claude (along with recent pod logs) for a deeper root-cause writeup,
and the chat box becomes a real AI assistant grounded in your live cluster
state.

## Setup

```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Optional: enable AI-powered explanations

```bash
export ANTHROPIC_API_KEY=sk-ant-...
# optional, defaults to claude-sonnet-4-5
export ANTHROPIC_MODEL=claude-sonnet-4-5
```

### Optional: point at a real cluster

The app uses your default kubeconfig automatically (same as `kubectl`) — no
extra config needed if `kubectl get pods` already works on your machine. To
use a specific context/config:

```bash
export KUBECONFIG=/path/to/kubeconfig
```

If it can't reach a cluster, it silently falls back to demo data — the app
never crashes for lack of a cluster.

## Run

```bash
cd backend
python app.py
# or: uvicorn app:app --host 0.0.0.0 --port 8000
```

Open **http://localhost:8000** — the dashboard is served directly by the
backend (no separate frontend build step).

## Don't have a cluster to test against?

`terraform/` contains a ready-to-apply Terraform config that stands up a
small, throwaway EKS cluster on AWS (2 nodes, ~$0.35-0.45/hr), plus
`k8s/sample-broken-workloads.yaml` to seed it with real CrashLoopBackOff /
OOMKilled / ImagePullBackOff / Pending failures so you can see the dashboard
detect them against a live cluster. See `terraform/README.md` for the full
walkthrough (apply → point kubectl at it → seed failures → destroy when
done).

## Deploying inside the cluster (optional)

`k8s/rbac.yaml` and `k8s/deployment.yaml` are ready to apply as-is (edit the
`image:` field first). To run this as an in-cluster service instead of from
your laptop, build the included `Dockerfile`, push it to your registry, and
grant the pod's service account read access via RBAC:

```yaml
apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRole
metadata:
  name: k8s-troubleshooter-reader
rules:
  - apiGroups: [""]
    resources: ["pods", "events", "nodes", "pods/log"]
    verbs: ["get", "list"]
  - apiGroups: ["apps"]
    resources: ["deployments"]
    verbs: ["get", "list"]
```

Bind it to the Deployment's service account with a ClusterRoleBinding, and
set `ANTHROPIC_API_KEY` via a Secret/env var on the container.

## API reference

| Endpoint | Method | Purpose |
|---|---|---|
| `/api/status` | GET | live vs demo mode, whether AI is enabled |
| `/api/overview` | GET | cluster-wide counts + issue severity totals |
| `/api/issues` | GET | all detected issues (rule engine output) |
| `/api/pods` | GET | pod list with container states |
| `/api/deployments` | GET | deployment rollout status |
| `/api/nodes` | GET | node conditions |
| `/api/events` | GET | recent Kubernetes events |
| `/api/logs?namespace=&pod=` | GET | tail of a pod's logs |
| `/api/diagnose` | POST `{issue_id, namespace}` | AI root-cause + remediation for one issue |
| `/api/chat` | POST `{question, namespace}` | free-form Q&A grounded in current cluster state |

## Project layout

```
backend/
  app.py            FastAPI app + routes, serves the frontend
  k8s_client.py      kubeconfig-based cluster reader + mock data fallback
  diagnostics.py      rule engine that turns raw state into Issues
  ai_analyzer.py       Claude integration + rule-based fallback explanations
  requirements.txt
frontend/
  index.html         single-page dashboard (vanilla JS, no build step)
Dockerfile
```
